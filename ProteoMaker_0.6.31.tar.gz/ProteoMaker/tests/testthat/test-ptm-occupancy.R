library(testthat)

# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

# Build a parameters list with NumCond conditions × NumReps replicates.
# QuantColnames are ordered as: C_1_R_1, ..., C_1_R_n, C_2_R_1, ..., C_nc_R_n
make_params <- function(num_cond = 2, num_reps = 2) {
  quant_cols <- paste0(
    "C_", rep(seq_len(num_cond), each = num_reps),
    "_R_", rep(seq_len(num_reps), num_cond)
  )
  list(QuantColnames = quant_cols, NumCond = num_cond, NumReps = num_reps)
}

# Build a minimal peptable with one modified row, one counterpart unmodified row,
# and one non-counterpart unmodified row (different sequence, same protein).
# mod_vals / unmod_vals / other_vals are log2-scale vectors, one entry per column.
# other_vals defaults to unmod_vals for backward compatibility (Rprot = Ru when
# both share the same values, which is a degenerate case for the occupancy formula
# but sufficient for structural tests).
make_peptable <- function(mod_vals, unmod_vals, other_vals = unmod_vals,
                          ptmpos    = list(c(3L)),
                          ptmtype   = list(c("ph")),
                          quant_cols = make_params()$QuantColnames) {
  n_cols <- length(quant_cols)
  stopifnot(length(mod_vals) == n_cols, length(unmod_vals) == n_cols)

  mod_row <- data.frame(Sequence = "AASPEPR", stringsAsFactors = FALSE)
  mod_row[quant_cols] <- as.list(mod_vals)
  mod_row$PTMType    <- ptmtype
  mod_row$PTMPos     <- ptmpos
  mod_row$Accession  <- list("P12345")
  mod_row$Start      <- list(10L)
  mod_row$Stop       <- list(16L)

  unmod_row <- data.frame(Sequence = "AASPEPR", stringsAsFactors = FALSE)
  unmod_row[quant_cols] <- as.list(unmod_vals)
  unmod_row$PTMType  <- list(character(0))
  unmod_row$PTMPos   <- list(integer(0))
  unmod_row$Accession <- list("P12345")
  unmod_row$Start    <- list(10L)
  unmod_row$Stop     <- list(16L)

  # Non-counterpart unmodified peptide: different sequence, same protein.
  # Required for Rprot computation.
  other_row <- data.frame(Sequence = "BGPEPTIDE", stringsAsFactors = FALSE)
  other_row[quant_cols] <- as.list(other_vals)
  other_row$PTMType  <- list(character(0))
  other_row$PTMPos   <- list(integer(0))
  other_row$Accession <- list("P12345")
  other_row$Start    <- list(30L)
  other_row$Stop     <- list(38L)

  rbind(mod_row, unmod_row, other_row)
}

# ──────────────────────────────────────────────────────────────────────────────
# Basic correctness  (2 conditions × 2 replicates)
# ──────────────────────────────────────────────────────────────────────────────

test_that("calcPTMOccupancy returns one row per PTM site", {
  pep <- make_peptable(mod_vals = c(1, 1, 2, 2), unmod_vals = c(1, 1, 1, 1))
  occ <- calcPTMOccupancy(pep, make_params())

  expect_equal(nrow(occ), 1L)
})

test_that("calcPTMOccupancy skips peptides with ambiguous protein start positions", {
  pep <- make_peptable(mod_vals = c(1, 1, 2, 2), unmod_vals = c(1, 1, 1, 1))
  pep$Start <- I(list(c(10L, 20L), 10L, 40L))

  occ <- calcPTMOccupancy(pep, make_params())

  expect_equal(nrow(occ), 0L)
})

test_that("calcPTMOccupancy skips peptides with ambiguous accessions", {
  pep <- make_peptable(mod_vals = c(1, 1, 2, 2), unmod_vals = c(1, 1, 1, 1))
  pep$Accession[[1]] <- c("P12345", "P67890")

  occ <- calcPTMOccupancy(pep, make_params())

  expect_equal(nrow(occ), 0L)
})

test_that("formula correctly estimates reference-condition occupancy occ_1", {
  # 2 conditions, 1 replicate each.
  # mod: ref=0, C2=2 (log2)  =>  Rm = 2^(2-0) = 4
  # unmod: ref=0, C2=0        =>  Ru = 2^(0-0) = 1
  # other: ref=0, C2=1        =>  Rprot = 2^(1-0) = 2
  # occ_1 = (Rprot - Ru) / (Rm - Ru) = (2 - 1) / (4 - 1) = 1/3
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames
  pep    <- make_peptable(mod_vals   = c(0, 2), unmod_vals = c(0, 0),
                          other_vals = c(0, 1), quant_cols = qc)
  occ    <- calcPTMOccupancy(pep, params)

  expect_equal(as.numeric(occ[1, "C_1"]), 1/3, tolerance = 1e-9)
})

test_that("formula correctly computes per-condition occupancy as occ_1 * Rm / Rprot", {
  # Same setup as above: occ_1 = 1/3, Rm = 4, Rprot = 2
  # occ_2 = occ_1 * Rm / Rprot = (1/3) * 4 / 2 = 2/3
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames
  pep    <- make_peptable(mod_vals   = c(0, 2), unmod_vals = c(0, 0),
                          other_vals = c(0, 1), quant_cols = qc)
  occ    <- calcPTMOccupancy(pep, params)

  expect_equal(as.numeric(occ[1, "C_2"]), 2/3, tolerance = 1e-9)
})

test_that("occupancy approaches 0 when modified ratio << protein ratio", {
  # 2 conditions, 2 replicates: mod unchanged (Rm=1), unmod and protein increase 1024x (Ru=Rprot=1024).
  # occ_1 = (Rprot - Ru) / (Rm - Ru) = (1024-1024)/(1-1024) = 0
  # occ_2 = occ_1 * Rm / Rprot = 0  (denominator is degenerate: Rm=Ru)
  pep <- make_peptable(mod_vals = c(1, 1, 1, 1), unmod_vals = c(1, 1, 11, 11))
  occ <- calcPTMOccupancy(pep, make_params())

  expect_true(as.numeric(occ[1, "C_2"]) < 0.01)
})

# ──────────────────────────────────────────────────────────────────────────────
# Output structure
# ──────────────────────────────────────────────────────────────────────────────

test_that("output contains expected columns (Sequence, Peptidoform, Accession, PTMPos, ProteinPTMPos, PTMType, C_1, C_2)", {
  pep <- make_peptable(mod_vals = c(1, 1, 2, 2), unmod_vals = c(1, 1, 1, 1))
  occ <- calcPTMOccupancy(pep, make_params())

  expect_true(all(c("Sequence", "Peptidoform", "Accession", "PTMPos", "ProteinPTMPos", "PTMType", "C_1", "C_2") %in% names(occ)))
})

test_that("ProteinPTMPos reports protein-level modification positions when Start is available", {
  pep <- make_peptable(mod_vals = c(1, 1, 2, 2), unmod_vals = c(1, 1, 1, 1))
  pep$Start <- I(list(10L, 10L, 40L))

  occ <- calcPTMOccupancy(pep, make_params())

  expect_identical(occ$PTMPos[[1]], "3")
  expect_identical(occ$ProteinPTMPos[[1]], 12L)
})

test_that("C_1 column contains the estimated reference-condition occupancy occ_1", {
  # Decreasing occupancy case: mod stays, unmod increases, protein doubles.
  # mod: ref=0, C2=0  =>  Rm = 1
  # unmod: ref=0, C2=2 =>  Ru = 4
  # other: ref=0, C2=1 =>  Rprot = 2
  # occ_1 = (Rprot - Ru) / (Rm - Ru) = (2 - 4) / (1 - 4) = 2/3
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames
  pep    <- make_peptable(mod_vals   = c(0, 0), unmod_vals = c(0, 2),
                          other_vals = c(0, 1), quant_cols = qc)
  occ    <- calcPTMOccupancy(pep, params)

  expect_equal(as.numeric(occ[1, "C_1"]), 2/3, tolerance = 1e-9)
})

test_that("both C_1 and non-reference occupancy values are in (0, 1) for consistent data", {
  # Canonical consistent data: occ_1 = 1/3, occ_2 = 2/3
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames
  pep    <- make_peptable(mod_vals   = c(0, 2), unmod_vals = c(0, 0),
                          other_vals = c(0, 1), quant_cols = qc)
  occ    <- calcPTMOccupancy(pep, params)

  c1_val <- as.numeric(occ[1, "C_1"])
  c2_val <- as.numeric(occ[1, "C_2"])
  expect_false(is.na(c1_val))
  expect_true(c1_val > 0 && c1_val < 1)
  expect_false(is.na(c2_val))
  expect_true(c2_val > 0 && c2_val < 1)
})

# ──────────────────────────────────────────────────────────────────────────────
# Edge cases
# ──────────────────────────────────────────────────────────────────────────────

test_that("returns empty data.frame when no modified peptides exist", {
  params <- make_params()
  qc     <- params$QuantColnames

  unmod_row <- data.frame(Sequence = "PEPTIDE", stringsAsFactors = FALSE)
  unmod_row[qc] <- as.list(rep(2, length(qc)))
  unmod_row$PTMType   <- list(character(0))
  unmod_row$PTMPos    <- list(integer(0))
  unmod_row$Accession <- list("P99999")

  occ <- calcPTMOccupancy(unmod_row, params)
  expect_equal(nrow(occ), 0L)
})

test_that("returns empty data.frame when modified peptide has no unmodified counterpart", {
  params <- make_params()
  qc     <- params$QuantColnames

  mod_row <- data.frame(Sequence = "UNIQUEPEP", stringsAsFactors = FALSE)
  mod_row[qc] <- as.list(rep(3, length(qc)))
  mod_row$PTMType   <- list("ph")
  mod_row$PTMPos    <- list(2L)
  mod_row$Accession <- list("P00000")

  occ <- calcPTMOccupancy(mod_row, params)
  expect_equal(nrow(occ), 0L)
})

test_that("returns empty data.frame when NumCond < 2", {
  pep <- make_peptable(
    mod_vals   = c(1, 2),
    unmod_vals = c(1, 2),
    quant_cols = c("C_1_R_1", "C_1_R_2")
  )
  occ <- calcPTMOccupancy(pep, list(QuantColnames = c("C_1_R_1", "C_1_R_2"),
                                    NumCond = 1L, NumReps = 2L))
  expect_equal(nrow(occ), 0L)
})

test_that("returns empty data.frame when NumCond/NumReps absent from parameters", {
  pep <- make_peptable(mod_vals = c(1, 1, 2, 2), unmod_vals = c(1, 1, 1, 1))
  occ <- calcPTMOccupancy(pep, list(QuantColnames = make_params()$QuantColnames))
  expect_equal(nrow(occ), 0L)
})

# ──────────────────────────────────────────────────────────────────────────────
# NA propagation
# ──────────────────────────────────────────────────────────────────────────────

test_that("NA in a single-replicate condition propagates via occ_1 to all output columns", {
  # occ_1 is the mean of per-condition terms.  A NaN in any condition (arising
  # from mean(c(NA), na.rm = TRUE) = NaN) propagates through the mean because
  # NaN is not NA and is not removed by na.rm = TRUE.  The result is occ_1 = NaN,
  # which makes all columns NaN.  In R, is.na(NaN) == TRUE.
  params <- make_params(num_cond = 3, num_reps = 1)
  qc     <- params$QuantColnames   # C_1_R_1, C_2_R_1, C_3_R_1

  pep <- make_peptable(
    mod_vals   = c(0, NA, 2),   # NA in condition 2's only replicate → mod_mean[2] = NaN
    unmod_vals = c(0,  0, 0),
    other_vals = c(0,  1, 1),
    quant_cols = qc
  )
  occ <- calcPTMOccupancy(pep, params)

  expect_true(is.na(occ[1, "C_1"]))  # occ_1 = NaN (is.na(NaN) == TRUE)
  expect_true(is.na(occ[1, "C_2"]))  # NaN propagated via occ_1
  expect_true(is.na(occ[1, "C_3"]))  # NaN propagated via occ_1
})

test_that("NA in one of multiple replicates is silently removed (na.rm = TRUE)", {
  # mean(c(NA, x), na.rm = TRUE) = x: a single missing replicate is excluded and
  # the remaining replicate(s) are used.  The result equals the no-NA case.
  params <- make_params(num_cond = 2, num_reps = 2)
  qc     <- params$QuantColnames   # C_1_R_1, C_1_R_2, C_2_R_1, C_2_R_2

  pep_with_na <- make_peptable(
    mod_vals   = c(NA, 0, 2, 2),  # NA in C_1_R_1; mean of C_1 = 0
    unmod_vals = c(0, 0, 0, 0),
    other_vals = c(0, 0, 1, 1),
    quant_cols = qc
  )
  pep_complete <- make_peptable(
    mod_vals   = c(0, 0, 2, 2),   # same values without NA
    unmod_vals = c(0, 0, 0, 0),
    other_vals = c(0, 0, 1, 1),
    quant_cols = qc
  )

  occ_na  <- calcPTMOccupancy(pep_with_na,  params)
  occ_cmp <- calcPTMOccupancy(pep_complete, params)

  expect_equal(as.numeric(occ_na[1, "C_1"]), as.numeric(occ_cmp[1, "C_1"]), tolerance = 1e-9)
  expect_equal(as.numeric(occ_na[1, "C_2"]), as.numeric(occ_cmp[1, "C_2"]), tolerance = 1e-9)
})

test_that("NA in non-counterpart background propagates via occ_1 to all output columns", {
  # Rprot for the NA condition becomes NaN, which propagates through the occ_1
  # mean to all columns (NaN is not removed by na.rm = TRUE in mean()).
  params <- make_params(num_cond = 3, num_reps = 1)
  qc     <- params$QuantColnames

  mod_row <- data.frame(Sequence = "PEPTIDE", stringsAsFactors = FALSE)
  mod_row[qc] <- as.list(c(0, 2, 2))
  mod_row$PTMType   <- list("ph")
  mod_row$PTMPos    <- list(1L)
  mod_row$Accession <- list("P33333")

  # Counterpart unmodified (same sequence as modified)
  unmod_same <- data.frame(Sequence = "PEPTIDE", stringsAsFactors = FALSE)
  unmod_same[qc] <- as.list(c(0, 0, 0))
  unmod_same$PTMType <- list(character(0)); unmod_same$PTMPos <- list(integer(0))
  unmod_same$Accession <- list("P33333")

  # Non-counterpart unmodified: NA in condition 2 → Rprot_2 = NaN
  other_row <- data.frame(Sequence = "OTHERPEP", stringsAsFactors = FALSE)
  other_row[qc] <- as.list(c(0, NA, 1))
  other_row$PTMType <- list(character(0)); other_row$PTMPos <- list(integer(0))
  other_row$Accession <- list("P33333")

  pep <- rbind(mod_row, unmod_same, other_row)
  pep$Start <- I(list(10L, 10L, 30L))
  pep$Stop <- I(list(16L, 16L, 37L))
  occ <- calcPTMOccupancy(pep, params)

  expect_true(is.na(occ[1, "C_1"]))   # occ_1 = NaN (is.na(NaN) == TRUE)
  expect_true(is.na(occ[1, "C_2"]))   # NaN propagated via occ_1
  expect_true(is.na(occ[1, "C_3"]))   # NaN propagated via occ_1
})

# ──────────────────────────────────────────────────────────────────────────────
# Multiple unmodified rows: geometric mean per condition
# ──────────────────────────────────────────────────────────────────────────────

test_that("site with multiple covering unmodified peptides is averaged without warning", {
  # Multiple unmodified peptides covering the same protein site are valid site
  # support rows and are averaged into Ru.
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames   # C_1_R_1, C_2_R_1

  mod_row <- data.frame(Sequence = "MYPEPTIDE", stringsAsFactors = FALSE)
  mod_row[qc] <- as.list(c(2, 2))
  mod_row$PTMType <- list("ph"); mod_row$PTMPos <- list(1L)
  mod_row$Accession <- list("P11111")

  unmod1 <- data.frame(Sequence = "MYPEPTIDE", stringsAsFactors = FALSE)
  unmod1[qc] <- as.list(c(1, 1))
  unmod1$PTMType <- list(character(0)); unmod1$PTMPos <- list(integer(0))
  unmod1$Accession <- list("P11111")

  unmod2 <- data.frame(Sequence = "MYPEPTIDE", stringsAsFactors = FALSE)
  unmod2[qc] <- as.list(c(3, 3))
  unmod2$PTMType <- list(character(0)); unmod2$PTMPos <- list(integer(0))
  unmod2$Accession <- list("P11111")

  # Non-counterpart unmodified row required for Rprot
  other <- data.frame(Sequence = "OTHERPEP", stringsAsFactors = FALSE)
  other[qc] <- as.list(c(2, 3))
  other$PTMType <- list(character(0)); other$PTMPos <- list(integer(0))
  other$Accession <- list("P11111")

  pep <- rbind(mod_row, unmod1, unmod2, other)
  pep$Start <- I(list(10L, 10L, 10L, 30L))
  pep$Stop <- I(list(18L, 18L, 18L, 37L))

  expect_warning(occ <- calcPTMOccupancy(pep, params), NA)
  expect_equal(nrow(occ), 1L)
})

test_that("different unmodified peptide covering the PTM site contributes to Ru", {
  # The unmodified peptide has a different stripped sequence, e.g. due to a
  # missed cleavage, but still covers the same protein residue.
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames

  mod_row <- data.frame(Sequence = "MODSEQ", stringsAsFactors = FALSE)
  mod_row[qc] <- as.list(c(0, 2))
  mod_row$PTMType   <- list("ph")
  mod_row$PTMPos    <- list(3L)
  mod_row$Accession <- list("P11111")

  unmod_covering <- data.frame(Sequence = "XXMODSEQK", stringsAsFactors = FALSE)
  unmod_covering[qc] <- as.list(c(0, 0))
  unmod_covering$PTMType   <- list(character(0))
  unmod_covering$PTMPos    <- list(integer(0))
  unmod_covering$Accession <- list("P11111")

  other <- data.frame(Sequence = "OTHERPEP", stringsAsFactors = FALSE)
  other[qc] <- as.list(c(0, 1))
  other$PTMType   <- list(character(0))
  other$PTMPos    <- list(integer(0))
  other$Accession <- list("P11111")

  pep <- rbind(mod_row, unmod_covering, other)
  pep$Start <- I(list(10L, 8L, 30L))
  pep$Stop <- I(list(15L, 16L, 37L))

  occ <- calcPTMOccupancy(pep, params)

  expect_equal(nrow(occ), 1L)
  expect_equal(as.numeric(occ[1, "C_1"]), 1/3, tolerance = 1e-9)
  expect_equal(as.numeric(occ[1, "C_2"]), 2/3, tolerance = 1e-9)
})

test_that("multiple modified peptides for the same PTM site are averaged", {
  # Two different modified peptide sequences map to the same protein residue.
  # Their modified signal is averaged before the site occupancy is estimated.
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames

  make_row <- function(seq, vals, ptmtype, ptmpos, start, stop, acc = "P_SITE") {
    r <- data.frame(Sequence = seq, stringsAsFactors = FALSE)
    r[qc] <- as.list(vals)
    r$PTMType <- list(ptmtype)
    r$PTMPos <- list(ptmpos)
    r$Accession <- list(acc)
    r$Start <- list(start)
    r$Stop <- list(stop)
    r
  }

  pep <- rbind(
    make_row("SITEMOD_A", c(0, 2), "ph", 1L, 10L, 18L),
    make_row("SITEMOD_B", c(0, 0), "ph", 3L, 8L, 16L),
    make_row("COVERING", c(0, 0), character(0), integer(0), 8L, 18L),
    make_row("BACKGROUND", c(0, log2(1.5)), character(0), integer(0), 30L, 40L)
  )

  expect_warning(occ <- calcPTMOccupancy(pep, params), NA)

  expect_equal(nrow(occ), 1L)
  expect_equal(occ$ProteinPTMPos[[1]], 10L)
  expect_equal(sort(occ$Sequence), "SITEMOD_A;SITEMOD_B")
  expect_equal(occ$PTMPos[[1]], "1;3")
  expect_equal(as.numeric(occ[1, "C_1"]), 0.5, tolerance = 1e-9)
  expect_equal(as.numeric(occ[1, "C_2"]), 2/3, tolerance = 1e-9)
})

# ──────────────────────────────────────────────────────────────────────────────
# Multiple modified peptidoforms for the same sequence
# ──────────────────────────────────────────────────────────────────────────────

test_that("sequence with multiple modified peptidoforms returns one row per PTM site", {
  # Different modified peptidoforms on the same peptide sequence can represent
  # different protein sites, so they are estimated separately.
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames

  mod1 <- data.frame(Sequence = "STYPEP", stringsAsFactors = FALSE)
  mod1[qc] <- as.list(c(2, 3))
  mod1$PTMType <- list("ph"); mod1$PTMPos <- list(1L)
  mod1$Accession <- list("P22222")

  mod2 <- data.frame(Sequence = "STYPEP", stringsAsFactors = FALSE)
  mod2[qc] <- as.list(c(2, 4))
  mod2$PTMType <- list("ph"); mod2$PTMPos <- list(2L)
  mod2$Accession <- list("P22222")

  unmod <- data.frame(Sequence = "STYPEP", stringsAsFactors = FALSE)
  unmod[qc] <- as.list(c(2, 2))
  unmod$PTMType <- list(character(0)); unmod$PTMPos <- list(integer(0))
  unmod$Accession <- list("P22222")

  # Non-counterpart unmodified row required for Rprot
  other <- data.frame(Sequence = "OTHERPEP", stringsAsFactors = FALSE)
  other[qc] <- as.list(c(2, 3))
  other$PTMType <- list(character(0)); other$PTMPos <- list(integer(0))
  other$Accession <- list("P22222")

  pep <- rbind(mod1, mod2, unmod, other)
  pep$Start <- I(list(10L, 10L, 10L, 30L))
  pep$Stop <- I(list(15L, 15L, 15L, 37L))

  expect_warning(occ <- calcPTMOccupancy(pep, params), NA)
  expect_equal(nrow(occ), 2L)
})

test_that("multiply modified peptidoform is retained as full supporting peptidoform", {
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames

  mod <- data.frame(Sequence = "STYPEP", stringsAsFactors = FALSE)
  mod[qc] <- as.list(c(2, 3))
  mod$PTMType <- list(c("ph", "ph")); mod$PTMPos <- list(c(1L, 2L))
  mod$Accession <- list("P22222")

  unmod <- data.frame(Sequence = "STYPEP", stringsAsFactors = FALSE)
  unmod[qc] <- as.list(c(2, 2))
  unmod$PTMType <- list(character(0)); unmod$PTMPos <- list(integer(0))
  unmod$Accession <- list("P22222")

  other <- data.frame(Sequence = "OTHERPEP", stringsAsFactors = FALSE)
  other[qc] <- as.list(c(2, 3))
  other$PTMType <- list(character(0)); other$PTMPos <- list(integer(0))
  other$Accession <- list("P22222")

  pep <- rbind(mod, unmod, other)
  pep$Start <- I(list(10L, 10L, 30L))
  pep$Stop <- I(list(15L, 15L, 37L))

  expect_warning(occ <- calcPTMOccupancy(pep, params), NA)
  expect_equal(nrow(occ), 2L)
  expect_true(all(occ$Peptidoform == "S[ph]T[ph]YPEP"))
})

# ──────────────────────────────────────────────────────────────────────────────
# More than 2 conditions
# ──────────────────────────────────────────────────────────────────────────────

test_that("three conditions produce per-condition occupancy columns C_1, C_2, C_3", {
  # 3 conditions, 1 replicate each.
  # mod: ref=0, C2=2, C3=2  =>  Rm = [4, 4]
  # unmod: ref=0, C2=0, C3=0 =>  Ru = [1, 1]
  # other: ref=0, C2=1, C3=1 =>  Rprot = [2, 2]
  # occ_1 = mean([(2-1)/(4-1), (2-1)/(4-1)]) = 1/3
  # occ_2 = (1/3) * 4 / 2 = 2/3
  # occ_3 = (1/3) * 4 / 2 = 2/3
  params <- make_params(num_cond = 3, num_reps = 1)
  qc     <- params$QuantColnames
  pep    <- make_peptable(mod_vals   = c(0, 2, 2),
                          unmod_vals = c(0, 0, 0),
                          other_vals = c(0, 1, 1),
                          quant_cols = qc)
  occ    <- calcPTMOccupancy(pep, params)

  expect_equal(as.numeric(occ[1, "C_1"]), 1/3, tolerance = 1e-9)
  expect_equal(as.numeric(occ[1, "C_2"]), 2/3, tolerance = 1e-9)
  expect_equal(as.numeric(occ[1, "C_3"]), 2/3, tolerance = 1e-9)
})

test_that("formula correctly handles decreasing occupancy (occ_1 > occ_2)", {
  # Decreasing occupancy case where occ_1 = 2/3 and occ_2 = 1/3.
  # mod: ref=0, C2=0  =>  Rm = 2^(0-0) = 1
  # unmod: ref=0, C2=2 =>  Ru = 2^(2-0) = 4
  # other: ref=0, C2=1 =>  Rprot = 2^(1-0) = 2
  # occ_1 = (2 - 4) / (1 - 4) = (-2)/(-3) = 2/3
  # occ_2 = (2/3) * 1 / 2 = 1/3
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames

  pep <- make_peptable(mod_vals   = c(0, 0),
                       unmod_vals = c(0, 2),
                       other_vals = c(0, 1),
                       quant_cols = qc)
  occ <- calcPTMOccupancy(pep, params)

  expect_equal(as.numeric(occ[1, "C_1"]), 2/3, tolerance = 1e-9)
  expect_equal(as.numeric(occ[1, "C_2"]), 1/3, tolerance = 1e-9)
})

# ──────────────────────────────────────────────────────────────────────────────
# Protein ratio from non-counterpart unmodified peptides only (requirement c)
# ──────────────────────────────────────────────────────────────────────────────

test_that("protein ratio uses only non-counterpart unmodified peptides", {
  # Protein P12345 has two peptides:
  #   - MODSEQ: observed as both modified and unmodified (counterpart)
  #   - OTHERPEP: observed as unmodified only (non-counterpart)
  # The protein ratio Rprot must use ONLY OTHERPEP; the counterpart is excluded.
  #
  # 2 conditions, 1 replicate each.
  # Modified MODSEQ:       ref=0, C2=2  =>  Rm = 2^(2-0) = 4
  # Unmodified MODSEQ:     ref=0, C2=0  =>  Ru = 1  (excluded from Rprot)
  # Unmodified OTHERPEP:   ref=0, C2=1  =>  Rprot = 2^(1-0) = 2
  # occ_1 = (2 - 1) / (4 - 1) = 1/3
  # occ_2 = (1/3) * 4 / 2 = 2/3
  # If counterpart (ref=0,C2=0) were also included in Rprot:
  #   colMeans of [0,0] and [0,1] = [0, 0.5], Rprot = sqrt(2) ≈ 1.414
  #   occ_1 ≈ (1.414 - 1)/(4 - 1) ≈ 0.138, occ_2 ≈ 0.39  (different!)
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames

  mod_row <- data.frame(Sequence = "MODSEQ", stringsAsFactors = FALSE)
  mod_row[qc] <- as.list(c(0, 2))
  mod_row$PTMType   <- list("ph")
  mod_row$PTMPos    <- list(1L)
  mod_row$Accession <- list("P12345")

  unmod_same <- data.frame(Sequence = "MODSEQ", stringsAsFactors = FALSE)
  unmod_same[qc] <- as.list(c(0, 0))
  unmod_same$PTMType   <- list(character(0))
  unmod_same$PTMPos    <- list(integer(0))
  unmod_same$Accession <- list("P12345")

  unmod_other <- data.frame(Sequence = "OTHERPEP", stringsAsFactors = FALSE)
  unmod_other[qc] <- as.list(c(0, 1))
  unmod_other$PTMType   <- list(character(0))
  unmod_other$PTMPos    <- list(integer(0))
  unmod_other$Accession <- list("P12345")

  pep <- rbind(mod_row, unmod_same, unmod_other)
  pep$Start <- I(list(10L, 10L, 30L))
  pep$Stop <- I(list(15L, 15L, 37L))
  occ <- calcPTMOccupancy(pep, params)

  expect_equal(nrow(occ), 1L)
  # Must equal 2/3 (Rprot from OTHERPEP only), not ≈ 0.39 (if counterpart included)
  expect_equal(as.numeric(occ[1, "C_2"]), 2/3, tolerance = 1e-9)
})

test_that("returns empty data.frame when modified peptide has no non-counterpart unmodified peptides", {
  # Only a counterpart unmodified exists (same sequence); no other unmodified
  # peptides from the same protein → Rprot cannot be computed → skip.
  params <- make_params()
  qc     <- params$QuantColnames

  mod_row <- data.frame(Sequence = "UNIQUEPEP", stringsAsFactors = FALSE)
  mod_row[qc] <- as.list(rep(3, length(qc)))
  mod_row$PTMType   <- list("ph")
  mod_row$PTMPos    <- list(2L)
  mod_row$Accession <- list("P00001")

  unmod_row <- data.frame(Sequence = "UNIQUEPEP", stringsAsFactors = FALSE)
  unmod_row[qc] <- as.list(rep(2, length(qc)))
  unmod_row$PTMType  <- list(character(0))
  unmod_row$PTMPos   <- list(integer(0))
  unmod_row$Accession <- list("P00001")

  pep <- rbind(mod_row, unmod_row)
  pep$Start <- I(list(10L, 10L))
  pep$Stop <- I(list(18L, 18L))

  occ <- calcPTMOccupancy(pep, params)
  expect_equal(nrow(occ), 0L)
})

# ──────────────────────────────────────────────────────────────────────────────
# Multiple proteins in the same peptable
# ──────────────────────────────────────────────────────────────────────────────

test_that("accession index is not contaminated across proteins", {
  # Two proteins with identical per-condition fold-changes but different
  # non-counterpart background peptides. If accession lookup leaks rows across
  # proteins, Rprot (and therefore both occupancy values) will be wrong.
  #
  # Protein A (P_AAA):
  #   mod SEQA:    ref=0, C2=2  => Rm = 4
  #   unmod SEQA:  ref=0, C2=0  => Ru = 1
  #   bg BGPEP_A:  ref=0, C2=1  => Rprot_A = 2
  #   occ_1_A = (2-1)/(4-1) = 1/3;  occ_2_A = (1/3)*4/2 = 2/3
  #
  # Protein B (P_BBB) — different background abundance change:
  #   mod SEQB:    ref=0, C2=2  => Rm = 4  (same as A)
  #   unmod SEQB:  ref=0, C2=0  => Ru = 1  (same as A)
  #   bg BGPEP_B:  ref=0, C2=3  => Rprot_B = 8
  #   occ_1_B = (8-1)/(4-1) = 7/3;  occ_2_B = (7/3)*4/8 = 7/6
  #
  # If the index leaks BGPEP_A into protein B's Rprot:
  #   colMeans of [0,1] and [0,3] = [0, 2], Rprot = 4
  #   occ_1_B = (4-1)/(4-1) = 1  (wrong!)
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames

  make_row <- function(seq, vals, ptmtype, ptmpos, acc) {
    r <- data.frame(Sequence = seq, stringsAsFactors = FALSE)
    r[qc] <- as.list(vals)
    r$PTMType   <- list(ptmtype)
    r$PTMPos    <- list(ptmpos)
    r$Accession <- list(acc)
    r$Start     <- list(if (startsWith(seq, "SEQ")) 10L else 30L)
    r$Stop      <- list(if (startsWith(seq, "SEQ")) 13L else 36L)
    r
  }

  pep <- rbind(
    make_row("SEQA",   c(0, 2), "ph",          1L,          "P_AAA"),
    make_row("SEQA",   c(0, 0), character(0),  integer(0),  "P_AAA"),
    make_row("BGPEP_A",c(0, 1), character(0),  integer(0),  "P_AAA"),
    make_row("SEQB",   c(0, 2), "ph",          1L,          "P_BBB"),
    make_row("SEQB",   c(0, 0), character(0),  integer(0),  "P_BBB"),
    make_row("BGPEP_B",c(0, 3), character(0),  integer(0),  "P_BBB")
  )

  occ <- calcPTMOccupancy(pep, params)

  expect_equal(nrow(occ), 2L)

  occ_a <- occ[occ$Sequence == "SEQA", ]
  occ_b <- occ[occ$Sequence == "SEQB", ]

  expect_equal(as.numeric(occ_a[1, "C_1"]), 1/3,  tolerance = 1e-9)
  expect_equal(as.numeric(occ_a[1, "C_2"]), 2/3,  tolerance = 1e-9)
  expect_equal(as.numeric(occ_b[1, "C_1"]), 7/3,  tolerance = 1e-9)
  expect_equal(as.numeric(occ_b[1, "C_2"]), 7/6,  tolerance = 1e-9)
})

test_that("modified peptide with no same-protein background is skipped even with background from another protein", {
  # Protein A has a modified peptide + counterpart unmodified, but NO background
  # unmodified peptide of its own. Protein B has an unmodified background peptide.
  # The Rprot lookup must not pick up protein B's background → protein A is skipped.
  params <- make_params(num_cond = 2, num_reps = 1)
  qc     <- params$QuantColnames

  make_row <- function(seq, vals, ptmtype, ptmpos, acc) {
    r <- data.frame(Sequence = seq, stringsAsFactors = FALSE)
    r[qc] <- as.list(vals)
    r$PTMType   <- list(ptmtype)
    r$PTMPos    <- list(ptmpos)
    r$Accession <- list(acc)
    r$Start     <- list(if (startsWith(seq, "SEQ")) 10L else 30L)
    r$Stop      <- list(if (startsWith(seq, "SEQ")) 13L else 36L)
    r
  }

  pep <- rbind(
    make_row("SEQA",   c(0, 2), "ph",         1L,         "P_AAA"),
    make_row("SEQA",   c(0, 0), character(0), integer(0), "P_AAA"),
    make_row("BGPEP_B",c(0, 1), character(0), integer(0), "P_BBB")  # different protein
  )

  occ <- calcPTMOccupancy(pep, params)
  expect_equal(nrow(occ), 0L)
})
